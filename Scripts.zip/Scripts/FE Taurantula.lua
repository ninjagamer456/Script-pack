loadstring(game:HttpGet(('https://raw.githubusercontent.com/0Ben1/fe/main/Sipder'),true))()

--REQUIRED hats/hair:
--https://www.roblox.com/catalog/48474313/Red-Roblox-Cap
--https://www.roblox.com/catalog/62724852/Chestnut-Bun
--https://www.roblox.com/catalog/451220849/Lavender-Updo
--https://www.roblox.com/catalog/48474294/ROBLOX-Girl-Hair
--https://www.roblox.com/catalog/376527115/Jade-Necklace-with-Shell-Pendant
--https://www.roblox.com/catalog/62234425/Brown-Hair
--https://www.roblox.com/catalog/63690008/Pal-Hair
--https://www.roblox.com/catalog/3409612660/International-Fedora-USA
--https://www.roblox.com/catalog/4047554959/International-Fedora-Brazil
--(you can wear one other hat/hair)