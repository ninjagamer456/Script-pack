while wait() do 
game:GetService('VirtualInputManager'):SendKeyEvent(true,'M',false,uwu)
end