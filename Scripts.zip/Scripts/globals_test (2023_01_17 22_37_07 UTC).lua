local Globals = {getconnections, getgc, getinstances, getnilinstances, getscripts, getloadedmodules, fireclickdetector,
firetouchinterest, isnetworkowner, gethiddenproperty, sethiddenproperty,
getsenv, getcallingscript, getrawmetatable, setrawmetatable, setreadonly, isreadonly, hookfunction, newcclosure,
checkcaller, decompile, setfflag, getnamecallmethod, setnamecallmethod, getspecialinfo, saveinstance, debug, debug.getconstants,
debug.getconstant, debug.setconstant, debug.getupvalues, debug.getupvalue, debug.setupvalue,
debug.getprotos, debug.getproto, debug.getstack, debug.setstack, debug.setmetatable,
debug.getregistry, debug.getinfo, getscriptbytecode, dumpstring, get_thread_identity, set_thread_identity}

local GlobalsNames = {"getconnections", "getgc", "getinstances", "getnilinstances", "getscripts", "getloadedmodules", "fireclickdetector",
"firetouchinterest", "isnetworkowner", "gethiddenproperty", "sethiddenproperty",
"getsenv", "getcallingscript", "getrawmetatable", "setrawmetatable", "setreadonly", "isreadonly", "hookfunction", "newcclosure",
"checkcaller","decompile", "setfflag", "getnamecallmethod", "setnamecallmethod", "getspecialinfo", "saveinstance", "debugtable", "debug.getconstants",
"debug.getconstant", "debug.setconstant", "debug.getupvalues", "debug.getupvalue", "debug.setupvalue",
"debug.getprotos", "debug.getproto", "debug.getstack", "debug.setstack", "debug.setmetatable",
"debug.getregistry", "debug.getinfo", "getscriptbytecode", "dumpstring", "get_thread_identity", "set_thread_identity"}

local succeededCount = 0
local succeeded = 0

for i,v in pairs(GlobalsNames) do
    if Globals[i] then
        print(v .. " | Success ✅")
        succeededCount = succeededCount + 1
    else
        warn(v .. " | Failure ⛔")
    end
end



local totalFunctions = #GlobalsNames
local successRate = succeededCount / totalFunctions
local remainingNumber = totalFunctions - succeededCount

print("\n")

print(succeededCount .. " out of " .. totalFunctions .. ".")
print("Failed in ".. remainingNumber .. " tests.")

if successRate == 1 then
    print("Test Results:")
    info("Your Exploit Succeeded In Every Test And Can Run Any Script Pretty Much")
elseif successRate >= 0.7 then
    print("Test Results:")
    warn("Your Exploit Supports Most Functions and Can Run all Generic Scripts and Many Complex Scripts")
elseif successRate >= 0.4 then
    print("Test Results:")
    warn("Your Exploit Supports Just Enough Functions To Run Most Generic Scripts And Some Complex Scripts")
else
    print("Test Results:")
    error("Your Exploit Doesn't Support Many Functions and Will Fail to Run Many Scripts.")
end